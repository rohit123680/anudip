import java.sql.*;
import java.util.Scanner;

public class StudentManagement {
    private static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    private static final String USER = "root";
    private static final String PASSWORD = "@Yush2005"; // Update if needed

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner sc = new Scanner(System.in)) {

            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("✅ Connected to MySQL!");

            int choice;
            do {
                System.out.println("\n===== STUDENT MANAGEMENT MENU =====");
                System.out.println("1. Add Student");
                System.out.println("2. View All Students");
                System.out.println("3. Search Student by ID");
                System.out.println("4. Update Student");
                System.out.println("5. Delete Student");
                System.out.println("0. Exit");
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();

                switch (choice) {
                    case 1 -> addStudent(conn, sc);
                    case 2 -> viewAllStudents(conn);
                    case 3 -> searchStudentById(conn, sc);
                    case 4 -> updateStudent(conn, sc);
                    case 5 -> deleteStudent(conn, sc);
                    case 0 -> System.out.println("👋 Exiting...");
                    default -> System.out.println("❌ Invalid choice.");
                }
            } while (choice != 0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void addStudent(Connection conn, Scanner sc) throws SQLException {
        System.out.print("Enter ID: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Course: ");
        String course = sc.nextLine();
        System.out.print("Enter Grade: ");
        String grade = sc.nextLine();

        String sql = "INSERT INTO students (id, name, course, grade) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.setString(3, course);
            pstmt.setString(4, grade);
            pstmt.executeUpdate();
            System.out.println("✅ Student added successfully.");
        }
    }

    private static void viewAllStudents(Connection conn) throws SQLException {
        String sql = "SELECT * FROM students";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.printf("\n%-5s %-20s %-15s %-5s\n", "ID", "Name", "Course", "Grade");
            System.out.println("--------------------------------------------------");
            while (rs.next()) {
                System.out.printf("%-5d %-20s %-15s %-5s\n",
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("course"),
                        rs.getString("grade"));
            }
        }
    }

    private static void searchStudentById(Connection conn, Scanner sc) throws SQLException {
        System.out.print("Enter Student ID to search: ");
        int id = sc.nextInt();
        String sql = "SELECT * FROM students WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("🎯 Student Found:");
                    System.out.printf("ID: %d, Name: %s, Course: %s, Grade: %s\n",
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("course"),
                            rs.getString("grade"));
                } else {
                    System.out.println("❌ Student not found.");
                }
            }
        }
    }

    private static void updateStudent(Connection conn, Scanner sc) throws SQLException {
        System.out.print("Enter Student ID to update: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter New Name: ");
        String name = sc.nextLine();
        System.out.print("Enter New Course: ");
        String course = sc.nextLine();
        System.out.print("Enter New Grade: ");
        String grade = sc.nextLine();

        String sql = "UPDATE students SET name = ?, course = ?, grade = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, course);
            pstmt.setString(3, grade);
            pstmt.setInt(4, id);
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("✅ Student updated successfully.");
            } else {
                System.out.println("❌ Student not found.");
            }
        }
    }

    private static void deleteStudent(Connection conn, Scanner sc) throws SQLException {
        System.out.print("Enter Student ID to delete: ");
        int id = sc.nextInt();
        String sql = "DELETE FROM students WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("🗑️ Student deleted successfully.");
            } else {
                System.out.println("❌ Student not found.");
            }
        }
    }
}
